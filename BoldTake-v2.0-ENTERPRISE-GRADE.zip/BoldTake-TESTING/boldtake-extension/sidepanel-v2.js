/**
 * BoldTake v2.0 - Professional Dashboard Controller
 * Enterprise-grade sidepanel with real-time updates
 */

'use strict';

class BoldTakeDashboard {
  constructor() {
    this.state = 'idle';
    this.metrics = {
      successCount: 0,
      totalProcessed: 0,
      errorCount: 0,
      startTime: null,
      todayReplies: 0,
      avgEngagement: 0
    };
    
    this.elements = {};
    this.activityBuffer = [];
    this.maxActivities = 50;
    
    this.init();
  }

  init() {
    console.log('🚀 BoldTake Dashboard v2.0 initializing...');
    
    this.cacheElements();
    this.setupEventListeners();
    this.startStatusListener();
    this.loadStoredMetrics();
    
    console.log('✅ Dashboard ready');
  }

  cacheElements() {
    // Status elements
    this.elements.statusIcon = document.getElementById('statusIcon');
    this.elements.statusText = document.getElementById('statusText');
    
    // Metric elements
    this.elements.successCount = document.getElementById('successCount');
    this.elements.totalProcessed = document.getElementById('totalProcessed');
    this.elements.errorCount = document.getElementById('errorCount');
    this.elements.todayReplies = document.getElementById('todayReplies');
    this.elements.successRate = document.getElementById('successRate');
    this.elements.avgEngagement = document.getElementById('avgEngagement');
    this.elements.runtime = document.getElementById('runtime');
    
    // Control elements
    this.elements.startButton = document.getElementById('startButton');
    this.elements.stopButton = document.getElementById('stopButton');
    this.elements.activityFeed = document.getElementById('activityFeed');
  }

  setupEventListeners() {
    // Start button
    this.elements.startButton?.addEventListener('click', () => {
      this.startAutomation();
    });

    // Stop button
    this.elements.stopButton?.addEventListener('click', () => {
      this.stopAutomation();
    });

    // Runtime updater
    setInterval(() => {
      if (this.state === 'running' && this.metrics.startTime) {
        this.updateRuntime();
      }
    }, 1000);
  }

  startStatusListener() {
    // Listen for status updates from content script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'status_update') {
        this.handleStatusUpdate(message);
      }
    });
  }

  async loadStoredMetrics() {
    try {
      const stored = await chrome.storage.local.get(['boldtake_metrics']);
      if (stored.boldtake_metrics) {
        this.metrics = { ...this.metrics, ...stored.boldtake_metrics };
        this.updateMetricsDisplay();
      }
    } catch (error) {
      console.log('⚠️ Failed to load stored metrics:', error);
    }
  }

  async saveMetrics() {
    try {
      await chrome.storage.local.set({ boldtake_metrics: this.metrics });
    } catch (error) {
      console.log('⚠️ Failed to save metrics:', error);
    }
  }

  async startAutomation() {
    console.log('🚀 Starting automation from dashboard...');
    
    this.state = 'running';
    this.metrics.startTime = Date.now();
    
    // Update UI
    this.elements.startButton.style.display = 'none';
    this.elements.stopButton.style.display = 'inline-block';
    
    this.updateStatus('working', '🚀 Starting intelligent automation...');
    this.clearEmptyState();
    
    // Send start command to content script
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'XENGAGER_START' });
      }
    } catch (error) {
      console.log('❌ Failed to send start command:', error);
      this.addActivity('error', '❌ Failed to start automation - make sure you\'re on X.com');
    }
  }

  async stopAutomation() {
    console.log('🛑 Stopping automation from dashboard...');
    
    this.state = 'idle';
    
    // Update UI
    this.elements.startButton.style.display = 'inline-block';
    this.elements.stopButton.style.display = 'none';
    
    this.updateStatus('ready', '⏹️ Automation stopped');
    
    // Send stop command to content script
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: 'XENGAGER_STOP' });
      }
    } catch (error) {
      console.log('❌ Failed to send stop command:', error);
    }
  }

  handleStatusUpdate(message) {
    console.log('📊 Status update:', message);
    
    this.updateStatus(message.status, message.message);
    
    // Update metrics if provided
    if (message.metrics) {
      this.metrics = { ...this.metrics, ...message.metrics };
      this.updateMetricsDisplay();
      this.saveMetrics();
    }
    
    // Add to activity feed
    this.addActivity(message.status, message.message, message.timestamp);
  }

  updateStatus(type, message) {
    // Update status icon
    const icons = {
      'ready': '⚡',
      'working': '🚀',
      'analyzing': '🧠',
      'posting': '✍️',
      'success': '🎯',
      'error': '❌',
      'paused': '⏸️'
    };

    if (this.elements.statusIcon) {
      this.elements.statusIcon.textContent = icons[type] || '⚡';
      this.elements.statusIcon.className = `status-icon ${type}`;
    }

    // Update status text
    if (this.elements.statusText) {
      this.elements.statusText.textContent = message;
    }
  }

  updateMetricsDisplay() {
    // Update metric displays
    if (this.elements.successCount) {
      this.elements.successCount.textContent = this.metrics.successCount || 0;
    }
    
    if (this.elements.totalProcessed) {
      this.elements.totalProcessed.textContent = this.metrics.totalProcessed || 0;
    }
    
    if (this.elements.errorCount) {
      this.elements.errorCount.textContent = this.metrics.errorCount || 0;
    }
    
    if (this.elements.todayReplies) {
      this.elements.todayReplies.textContent = this.metrics.todayReplies || 0;
    }
    
    // Calculate and update success rate
    const total = this.metrics.totalProcessed || 0;
    const successRate = total > 0 ? Math.round((this.metrics.successCount / total) * 100) : 100;
    if (this.elements.successRate) {
      this.elements.successRate.textContent = `${successRate}%`;
    }
    
    // Update average engagement (placeholder)
    if (this.elements.avgEngagement) {
      this.elements.avgEngagement.textContent = this.metrics.avgEngagement || 0;
    }
  }

  updateRuntime() {
    if (!this.metrics.startTime) return;
    
    const elapsed = Date.now() - this.metrics.startTime;
    const minutes = Math.floor(elapsed / 60000);
    const seconds = Math.floor((elapsed % 60000) / 1000);
    
    const runtime = minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
    
    if (this.elements.runtime) {
      this.elements.runtime.textContent = runtime;
    }
  }

  clearEmptyState() {
    if (this.elements.activityFeed) {
      const emptyState = this.elements.activityFeed.querySelector('.empty-state');
      if (emptyState) {
        emptyState.remove();
      }
    }
  }

  addActivity(type, message, timestamp = null) {
    this.clearEmptyState();
    
    const activity = {
      id: Date.now() + Math.random(),
      type: type,
      message: message,
      timestamp: timestamp || new Date().toISOString(),
      time: new Date().toLocaleTimeString()
    };
    
    // Add to buffer
    this.activityBuffer.unshift(activity);
    
    // Limit buffer size
    if (this.activityBuffer.length > this.maxActivities) {
      this.activityBuffer = this.activityBuffer.slice(0, this.maxActivities);
    }
    
    // Create activity element
    this.renderActivity(activity);
    
    // Auto-scroll to top
    if (this.elements.activityFeed) {
      this.elements.activityFeed.scrollTop = 0;
    }
  }

  renderActivity(activity) {
    if (!this.elements.activityFeed) return;
    
    const activityElement = document.createElement('div');
    activityElement.className = 'activity-item';
    activityElement.innerHTML = `
      <div class="activity-icon ${activity.type}">
        ${this.getActivityIcon(activity.type)}
      </div>
      <div class="activity-content">
        <div class="activity-message">${this.escapeHtml(activity.message)}</div>
        <div class="activity-time">${activity.time}</div>
      </div>
    `;
    
    // Insert at the beginning
    this.elements.activityFeed.insertBefore(activityElement, this.elements.activityFeed.firstChild);
    
    // Remove excess activities from DOM
    const activityItems = this.elements.activityFeed.querySelectorAll('.activity-item');
    if (activityItems.length > this.maxActivities) {
      for (let i = this.maxActivities; i < activityItems.length; i++) {
        activityItems[i].remove();
      }
    }
  }

  getActivityIcon(type) {
    const icons = {
      'ready': '⚡',
      'working': '🚀',
      'analyzing': '🧠',
      'posting': '✍️',
      'success': '🎯',
      'error': '❌',
      'paused': '⏸️'
    };
    return icons[type] || '⚡';
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Public API for external calls
  showActivity(type, message) {
    this.addActivity(type, message);
  }

  updateMetrics(newMetrics) {
    this.metrics = { ...this.metrics, ...newMetrics };
    this.updateMetricsDisplay();
    this.saveMetrics();
  }
}

// ===== INITIALIZATION =====

let dashboard = null;

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeDashboard);
} else {
  initializeDashboard();
}

function initializeDashboard() {
  dashboard = new BoldTakeDashboard();
  
  // Make dashboard globally accessible
  window.boldTakeDashboard = dashboard;
  
  // Add some initial demo activities
  setTimeout(() => {
    dashboard.addActivity('ready', '🎯 BoldTake Dashboard loaded and ready');
    dashboard.addActivity('ready', '💡 Go to X.com and click "Start AI Automation" to begin');
  }, 500);
}

console.log('🚀 BoldTake Dashboard v2.0 script loaded');
