/**
 * BoldTake v2.0 - Enterprise-Grade X.com Automation Engine
 * Built for 100% reliability, zero detection, professional quality
 */

'use strict';

// ===== ENTERPRISE-GRADE ARCHITECTURE =====

class BoldTakeEngine {
  constructor() {
    this.state = 'idle';
    this.config = {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,
      humanTypingSpeed: { min: 50, max: 150 },
      pauseBetweenActions: { min: 2000, max: 5000 }
    };
    this.metrics = {
      totalProcessed: 0,
      successCount: 0,
      errorCount: 0,
      startTime: null
    };
    this.errorRecovery = new ErrorRecoverySystem();
    this.xcomNative = new XComNativeIntegration();
    this.aiEngine = new AdvancedAIEngine();
    
    this.init();
  }

  async init() {
    this.log('🚀 BoldTake Engine v2.0 initializing...');
    
    try {
      await this.xcomNative.initialize();
      await this.setupEventListeners();
      this.updateStatus('ready', 'BoldTake Engine ready for automation');
      this.log('✅ Engine initialization complete');
    } catch (error) {
      this.handleCriticalError('Engine initialization failed', error);
    }
  }

  async start() {
    if (this.state !== 'idle') {
      this.log('⚠️ Engine already running, ignoring start request');
      return;
    }

    this.state = 'running';
    this.metrics.startTime = Date.now();
    this.updateStatus('working', '🚀 Starting intelligent automation...');
    
    try {
      await this.executeAutomationLoop();
    } catch (error) {
      await this.errorRecovery.handleError(error, () => this.executeAutomationLoop());
    }
  }

  async executeAutomationLoop() {
    this.log('🔄 Starting automation loop...');
    
    const tweets = await this.xcomNative.findHighValueTweets();
    this.updateStatus('analyzing', `🧠 Found ${tweets.length} high-value targets`);

    for (const tweet of tweets) {
      if (this.state !== 'running') break;

      try {
        await this.processTweet(tweet);
        await this.humanPause();
      } catch (error) {
        this.log(`❌ Tweet processing failed: ${error.message}`);
        this.metrics.errorCount++;
      }
    }

    this.state = 'idle';
    this.updateStatus('success', `✅ Automation complete: ${this.metrics.successCount} successful interactions`);
  }

  async processTweet(tweet) {
    this.log(`🔍 Processing tweet: ${tweet.id}`);
    this.updateStatus('analyzing', `🔍 Analyzing tweet from @${tweet.author}`);

    // Generate AI response
    const response = await this.aiEngine.generateResponse(tweet);
    this.updateStatus('working', `🤖 Generated perfect reply: "${response.slice(0, 50)}..."`);

    // Post response using native X.com methods
    await this.xcomNative.postReply(tweet, response);
    this.updateStatus('success', `✅ Successfully replied to @${tweet.author}`);

    this.metrics.successCount++;
    this.metrics.totalProcessed++;
  }

  async humanPause() {
    const delay = this.randomBetween(this.config.pauseBetweenActions.min, this.config.pauseBetweenActions.max);
    this.log(`⏱️ Human-like pause: ${delay}ms`);
    await this.sleep(delay);
  }

  updateStatus(type, message) {
    // Send to sidepanel
    chrome.runtime.sendMessage({
      type: 'status_update',
      status: type,
      message: message,
      timestamp: new Date().toISOString(),
      metrics: this.metrics
    }).catch(() => {});

    this.log(`📊 Status: ${message}`);
  }

  log(message) {
    console.log(`[BoldTake] ${message}`);
  }

  randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  handleCriticalError(context, error) {
    this.log(`💥 CRITICAL ERROR in ${context}: ${error.message}`);
    this.state = 'error';
    this.updateStatus('error', `❌ Critical error: ${error.message}`);
  }
}

// ===== ERROR RECOVERY SYSTEM =====

class ErrorRecoverySystem {
  constructor() {
    this.retryCount = 0;
    this.maxRetries = 3;
    this.backoffMultiplier = 2;
    this.baseDelay = 1000;
  }

  async handleError(error, retryFunction) {
    console.log(`🔄 Error recovery attempt ${this.retryCount + 1}/${this.maxRetries}`);
    
    if (this.retryCount >= this.maxRetries) {
      throw new Error(`Max retries exceeded: ${error.message}`);
    }

    const delay = this.baseDelay * Math.pow(this.backoffMultiplier, this.retryCount);
    console.log(`⏱️ Waiting ${delay}ms before retry...`);
    
    await new Promise(resolve => setTimeout(resolve, delay));
    this.retryCount++;

    try {
      await retryFunction();
      this.retryCount = 0; // Reset on success
    } catch (retryError) {
      await this.handleError(retryError, retryFunction);
    }
  }
}

// ===== NATIVE X.COM INTEGRATION =====

class XComNativeIntegration {
  constructor() {
    this.reactFiber = null;
    this.graphqlEndpoint = 'https://twitter.com/i/api/graphql';
  }

  async initialize() {
    console.log('🔗 Initializing native X.com integration...');
    
    // Find React Fiber root
    this.reactFiber = this.findReactFiber();
    
    if (!this.reactFiber) {
      throw new Error('Failed to connect to X.com React system');
    }

    console.log('✅ Connected to X.com native systems');
  }

  findReactFiber() {
    // Find React DevTools hook
    const reactDevTools = window.__REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (reactDevTools && reactDevTools.renderers) {
      for (const renderer of reactDevTools.renderers.values()) {
        if (renderer.findFiberByHostInstance) {
          return renderer;
        }
      }
    }
    return null;
  }

  async findHighValueTweets() {
    console.log('🎯 Finding high-value tweets...');
    
    // Use native selectors that work with X.com's current structure
    const tweetElements = document.querySelectorAll('[data-testid="tweet"]');
    const highValueTweets = [];

    for (const element of tweetElements) {
      try {
        const tweet = this.parseTweetElement(element);
        if (this.isHighValue(tweet)) {
          highValueTweets.push(tweet);
        }
      } catch (error) {
        console.log(`⚠️ Failed to parse tweet: ${error.message}`);
      }
    }

    console.log(`✅ Found ${highValueTweets.length} high-value tweets`);
    return highValueTweets.slice(0, 10); // Limit to top 10
  }

  parseTweetElement(element) {
    const authorElement = element.querySelector('[data-testid="User-Name"]');
    const textElement = element.querySelector('[data-testid="tweetText"]');
    const metricsElement = element.querySelector('[role="group"]');
    
    return {
      id: this.extractTweetId(element),
      author: authorElement?.textContent?.trim() || 'Unknown',
      text: textElement?.textContent?.trim() || '',
      element: element,
      metrics: this.parseMetrics(metricsElement)
    };
  }

  extractTweetId(element) {
    const links = element.querySelectorAll('a[href*="/status/"]');
    for (const link of links) {
      const match = link.href.match(/\/status\/(\d+)/);
      if (match) return match[1];
    }
    return `tweet_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  parseMetrics(metricsElement) {
    if (!metricsElement) return { likes: 0, retweets: 0, replies: 0 };

    const buttons = metricsElement.querySelectorAll('button');
    const metrics = { likes: 0, retweets: 0, replies: 0 };

    buttons.forEach(button => {
      const text = button.textContent || '';
      const number = this.parseMetricNumber(text);
      
      if (button.querySelector('[data-testid="like"]')) {
        metrics.likes = number;
      } else if (button.querySelector('[data-testid="retweet"]')) {
        metrics.retweets = number;
      } else if (button.querySelector('[data-testid="reply"]')) {
        metrics.replies = number;
      }
    });

    return metrics;
  }

  parseMetricNumber(text) {
    const match = text.match(/[\d,]+/);
    if (!match) return 0;
    return parseInt(match[0].replace(/,/g, ''), 10) || 0;
  }

  isHighValue(tweet) {
    return tweet.metrics.likes >= 100 || 
           tweet.metrics.retweets >= 50 || 
           tweet.author.includes('✓'); // Verified accounts
  }

  async postReply(tweet, response) {
    console.log(`✍️ Posting reply to tweet ${tweet.id}`);

    // Find and click reply button
    const replyButton = tweet.element.querySelector('[data-testid="reply"]');
    if (!replyButton) {
      throw new Error('Reply button not found');
    }

    // Simulate human click
    await this.simulateHumanClick(replyButton);
    await this.sleep(1000);

    // Wait for composer to appear
    const composer = await this.waitForComposer();
    if (!composer) {
      throw new Error('Reply composer did not appear');
    }

    // Type response with human-like behavior
    await this.typeHumanLike(composer, response);
    await this.sleep(1000);

    // Find and click send button
    const sendButton = document.querySelector('[data-testid="tweetButtonInline"]');
    if (!sendButton || sendButton.disabled) {
      throw new Error('Send button not available');
    }

    await this.simulateHumanClick(sendButton);
    console.log('✅ Reply posted successfully');
  }

  async simulateHumanClick(element) {
    // Scroll element into view
    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await this.sleep(500);

    // Add slight random offset to click position
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width * (0.3 + Math.random() * 0.4);
    const y = rect.top + rect.height * (0.3 + Math.random() * 0.4);

    // Dispatch events in proper sequence
    const events = ['mousedown', 'mouseup', 'click'];
    for (const eventType of events) {
      const event = new MouseEvent(eventType, {
        bubbles: true,
        cancelable: true,
        clientX: x,
        clientY: y
      });
      element.dispatchEvent(event);
      await this.sleep(50);
    }
  }

  async waitForComposer(timeout = 5000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const composer = document.querySelector('[data-testid="tweetTextarea_0"]');
      if (composer) return composer;
      await this.sleep(100);
    }
    
    return null;
  }

  async typeHumanLike(element, text) {
    console.log(`⌨️ Typing human-like: "${text.slice(0, 50)}..."`);
    
    // Focus element
    element.focus();
    await this.sleep(200);

    // Type each character with human-like delays
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      
      // Simulate key events
      const keydownEvent = new KeyboardEvent('keydown', {
        key: char,
        bubbles: true,
        cancelable: true
      });
      element.dispatchEvent(keydownEvent);

      // Insert character
      const inputEvent = new InputEvent('input', {
        data: char,
        inputType: 'insertText',
        bubbles: true,
        cancelable: true
      });
      
      element.textContent = element.textContent + char;
      element.dispatchEvent(inputEvent);

      // Human-like typing delay
      const delay = this.randomBetween(50, 150);
      await this.sleep(delay);
    }

    console.log('✅ Typing completed');
  }

  randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ===== ADVANCED AI ENGINE =====

class AdvancedAIEngine {
  constructor() {
    this.personalities = {
      expert: 'You are a knowledgeable industry expert sharing valuable insights',
      friendly: 'You are a friendly peer offering helpful perspectives', 
      analytical: 'You are a data-driven analyst providing sharp observations',
      creative: 'You are a creative thinker offering fresh perspectives'
    };
  }

  async generateResponse(tweet) {
    console.log('🤖 Generating AI response...');

    const personality = this.selectPersonality(tweet);
    const context = this.buildContext(tweet);
    
    const prompt = this.buildPrompt(personality, context, tweet.text);
    
    try {
      const response = await this.callOpenAI(prompt);
      const refined = this.refineResponse(response);
      
      console.log(`✅ Generated response: "${refined.slice(0, 50)}..."`);
      return refined;
    } catch (error) {
      console.log(`❌ AI generation failed: ${error.message}`);
      throw error;
    }
  }

  selectPersonality(tweet) {
    // Select personality based on tweet content
    if (tweet.text.includes('data') || tweet.text.includes('analytics')) {
      return 'analytical';
    } else if (tweet.text.includes('creative') || tweet.text.includes('design')) {
      return 'creative';
    } else if (tweet.metrics.likes > 1000) {
      return 'expert';
    } else {
      return 'friendly';
    }
  }

  buildContext(tweet) {
    return {
      author: tweet.author,
      engagement: tweet.metrics,
      platform: 'X.com',
      timeOfDay: new Date().getHours()
    };
  }

  buildPrompt(personality, context, tweetText) {
    return `${this.personalities[personality]}

Tweet to reply to: "${tweetText}"
Author: ${context.author}
Engagement: ${context.engagement.likes} likes, ${context.engagement.retweets} retweets

Write a thoughtful, engaging reply that:
- Adds genuine value to the conversation
- Feels natural and human
- Is 1-2 sentences maximum
- Avoids generic phrases
- Matches the tone of the original tweet

Reply:`;
  }

  async callOpenAI(prompt) {
    const response = await chrome.runtime.sendMessage({
      type: 'XENGAGER_OPENAI',
      payload: {
        templateId: 'custom',
        selectedText: prompt,
        model: 'gpt-4',
        language: 'English',
        tone: 'Professional',
        style: 'Conversational'
      }
    });

    if (!response?.ok) {
      throw new Error(response?.error || 'OpenAI API failed');
    }

    return response.text;
  }

  refineResponse(response) {
    // Remove common AI phrases and make it more human
    return response
      .replace(/^(Great|Interesting|Amazing|Fantastic)\s+(post|point|insight)!?\s*/i, '')
      .replace(/Thanks for sharing!?\s*/i, '')
      .replace(/I agree\.?\s*/i, '')
      .trim();
  }
}

// ===== INITIALIZATION =====

let boldTakeEngine = null;

// Initialize when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeBoldTake);
} else {
  initializeBoldTake();
}

function initializeBoldTake() {
  if (window.location.hostname.includes('twitter.com') || window.location.hostname.includes('x.com')) {
    boldTakeEngine = new BoldTakeEngine();
    
    // Listen for commands from popup
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'XENGAGER_START') {
        boldTakeEngine.start();
      } else if (message.type === 'XENGAGER_STOP') {
        boldTakeEngine.state = 'idle';
      }
    });
  }
}

console.log('🚀 BoldTake v2.0 Enterprise Engine loaded successfully');
