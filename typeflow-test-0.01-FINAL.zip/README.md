# BeLikeNative
![BeLikeNative](public/heading.svg)

# Get Started
- ```npm install```
- ```npm run watch```
- Load ```dist``` folder to web browser
