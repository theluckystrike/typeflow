async function load() {
  const { xengager_apiKey } = await chrome.storage.local.get({ xengager_apiKey: '' });
  document.getElementById('apiKey').value = xengager_apiKey;
}

async function save() {
  const apiKey = document.getElementById('apiKey').value.trim();
  await chrome.storage.local.set({ xengager_apiKey: apiKey });
  const el = document.getElementById('status');
  el.textContent = 'Saved';
  setTimeout(() => el.textContent = '', 1500);
}

document.getElementById('save').addEventListener('click', save);
load();


